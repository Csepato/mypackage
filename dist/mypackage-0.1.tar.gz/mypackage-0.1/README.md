# mypackage
This libraby was created as an example of how to puiblish your own python package.

# How to Install
...